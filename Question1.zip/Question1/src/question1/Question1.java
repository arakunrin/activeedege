package question1;

import java.util.Arrays;
import java.util.OptionalInt;

public class Question1 {

    public static void main(String[] args) {

        int arr[] = {0, 10, 1, -10, -20};
        int arr_size = arr.length;
        int rec = nonOccuring(arr, arr_size);
        System.out.println("The non occuring number is "
                + rec);
    }

    public static int checkPositiveNegative(int arr[], int size) {
        int j = 0, i;
        for (i = 0; i < size; i++) {
            if (arr[i] <= 0) {
                int temp;
                temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
                j++;
            }
        }

        return j;
    }

    public static int missingPositive(int arr[], int size) {
        int i;
        for (i = 0; i < size; i++) {
            int x = Math.abs(arr[i]);
            if (x - 1 < size && arr[x - 1] > 0) {
                arr[x - 1] = -arr[x - 1];
            }
        }

        for (i = 0; i < size; i++) {
            if (arr[i] > 0) {
                return i + 1;
            }
        }
        return size + 1;
    }

    public static int nonOccuring(int arr[], int size) {
        int shift = checkPositiveNegative(arr, size);
        int arr2[] = new int[size - shift];
        int j = 0;
        for (int i = shift; i < size; i++) {
            arr2[j] = arr[i];
            j++;
        }

        return missingPositive(arr2, j);
    }

}
