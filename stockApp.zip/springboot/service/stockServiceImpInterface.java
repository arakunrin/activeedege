import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.springframework.stereotype.Component;

import com.jackrutorial.model.Stock;

@Component
public class StockServiceImpl implements StockService {
 
 private static List<Stock> Stocks = new ArrayList<>();
 
 static {
  Stock s1 = new Stock(1, "apple", "300", "12/05/19-13/05/19");
  Stock s2 = new Stock(2, "orange", "250", "12/05/19-13/05/19");
  Stock s3 = new Stock(3, "banana", "125", "12/05/19-13/05/19");
  
  Stocks.add(s1);
  Stocks.add(s2);
  Stocks.add(s3);
 }

 @Override
 public List<Stock> getAllStock() {
  return Stocks;
 }

 @Override
 public Stock getStockById(int id) {
  for(Stock Stock : Stocks) {
   if(Stock.getId() == id) {
    return Stock;
   }
  }
  return null;
 }

 @Override
 public Stock addStock(Stock Stock) {
  Random random = new Random();
  int nextId = random.nextInt(1000) + 10;
  
  Stock.setId(nextId);
  Stocks.add(Stock);
  
  return Stock;
 }

 @Override
 public void updateStock(Stock Stock) {
  for(Stock prevStock : Stocks) {
   if(prevStock.getId() == Stock.getId()) {
    prevStock.setName(Stock.getName());
    prevStock.setEmail(Stock.getEmail());
    prevStock.setDescription(Stock.getDescription());
   }
  }
 }

 @Override
 public void deleteStock(int id) {
  for(Stock c : Stocks) {
   if(c.getId() == id) {
    Stocks.remove(c);
    break;
   }
  }
 }

}
