import java.util.List;

import com.Model.model.*;

public interface StockService {

 public List<Stock> getAllStock();
 
 public Stock getStockById(int id);
 
 public Stock addStock(Stock stock);
 
 public void updateStock(Stock stock);
 
 public void deleteStock(int id);
 
}