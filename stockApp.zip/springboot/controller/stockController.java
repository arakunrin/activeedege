import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.jackrutorial.model.Stock;
import com.jackrutorial.service.StockServiceImpInterface;

@RestController
public class StockController {
 
 @Autowired
 private StockServiceImpl stockService;
 
 @GetMapping("/stock/")
 public List<Stock> getAllStock(){
  return stockService.getAllStock();
 }
 
 @GetMapping("/stock/{stockId}")
 public Stock getStockById(@PathVariable int stockId) {
  return stockService.getStockById(stockId);
 }
 
 @PostMapping("/stock/")
 public ResponseEntity<Void> addStock(@RequestBody Stock newStock, UriComponentsBuilder builder){
  Stock stock = stockService.addStock(newStock);
  
  if(stock == null) {
   return ResponseEntity.noContent().build();
  }
  
  HttpHeaders headers = new HttpHeaders();
  headers.setLocation(builder.path("/stock/{id}").buildAndExpand(stock.getId()).toUri());
  return new ResponseEntity<Void>(headers, HttpStatus.CREATED);
 }
 
 @PutMapping("/stock/")
 public ResponseEntity<Stock> updateStock(@RequestBody Stock stock){
  Stock c = stockService.getStockById(stock.getId());
  
  if(c == null) {
   return new ResponseEntity<Stock>(HttpStatus.NOT_FOUND);
  }
  
  c.setName(stock.getName());
  c.setEmail(stock.getEmail());
  c.setDescription(stock.getDescription());
  
  stockService.updateStock(c);
  return new ResponseEntity<Stock>(c, HttpStatus.OK);
 }
 
 @DeleteMapping("/stock/{stockId}")
 public ResponseEntity<Stock> deleteStock(@PathVariable int stockId){
  Stock c = stockService.getStockById(stockId);
  
  if(c == null) {
   return new ResponseEntity<Stock>(HttpStatus.NOT_FOUND);
  }
  
  stockService.deleteStock(stockId);
  return new ResponseEntity<Stock>(HttpStatus.NO_CONTENT);
 }
}

